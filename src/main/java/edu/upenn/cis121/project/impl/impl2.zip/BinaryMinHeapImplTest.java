package edu.upenn.cis121.project.impl;

import org.junit.Test;

import edu.upenn.cis121.project.data.BinaryMinHeap;

public class BinaryMinHeapImplTest {
	
	@Test
	public void test() {
		BinaryMinHeap<Character,Integer> mh = new BinaryMinHeapImpl<Character,Integer>();
		mh.add('a',10);
		mh.add('b',5);
		mh.add('c',7);
		mh.decreaseKey('a', 4);
		System.out.println(mh.peek());
	}

}
