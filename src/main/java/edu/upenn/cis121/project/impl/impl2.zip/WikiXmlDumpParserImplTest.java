package edu.upenn.cis121.project.impl;

import java.io.File;
import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.junit.Test;

import edu.upenn.cis121.project.graph.DirectedGraph;


public class WikiXmlDumpParserImplTest {
	
	@Test
	public void constructor() throws IOException, XMLStreamException {
		File file = new File("example2.xml");
		WikiXmlDumpParserImpl wxdp = new WikiXmlDumpParserImpl();
		DirectedGraph<PageVertex> g = wxdp.parseXmlDump(file);
		PageVertex v = null;
		for (PageVertex p : g.vertexSet()) {
			//System.out.println(p.getId());
			if (p.getId().equals("April")){
				v = p;
			}
		}
		for (PageVertex p : g.outNeighbors(v)) {
			System.out.println(p.getId());
		}
		
	}
}
