package edu.upenn.cis121.project.impl;

import java.util.LinkedList;
import java.util.Set;

import edu.upenn.cis121.project.data.BinaryMinHeap;
import edu.upenn.cis121.project.graph.DoubleWeightedDirectedGraph;
import edu.upenn.cis121.project.graph.ShortestPath;

/**
 * @param <V> {@inheritDoc}
 *
 * @author eyeung, 16sp
 */
public class ShortestPathImpl<V> implements ShortestPath<V> {

    /**
     * {@inheritDoc}
     */
    @Override
    public Iterable<V> getShortestPath(DoubleWeightedDirectedGraph<V> G, V src, V tgt) {
    	if (G == null) {
    		throw new IllegalArgumentException();
    	}
    	if (src == null || !G.vertexSet().contains(src)) {
    		throw new IllegalArgumentException();
    	}
    	if (tgt == null || !G.vertexSet().contains(tgt)) {
    		throw new IllegalArgumentException();
    	}
    	Iterable<V> list = new LinkedList<V>();
    	Set<V> vertices = G.vertexSet();
    	
    	
    	int numVertices = G.vertexSet().size();
    	double[] distance = new double[numVertices + 1];
    	int[] parent = new int[numVertices + 1];
    	
    	BinaryMinHeap pq = new BinaryMinHeapImpl();
    	for (int i = 0; i < numVertices + 1; i++) {
    		distance[i] = Double.POSITIVE_INFINITY;
    		parent[i] = i;
    	}
    	
    	
        return list;
    }
}
