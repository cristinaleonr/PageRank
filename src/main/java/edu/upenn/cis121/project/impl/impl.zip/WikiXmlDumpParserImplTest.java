package edu.upenn.cis121.project.impl;

import java.io.File;
import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.junit.Test;

import edu.upenn.cis121.project.graph.DirectedGraph;

public class WikiXmlDumpParserImplTest {

}
