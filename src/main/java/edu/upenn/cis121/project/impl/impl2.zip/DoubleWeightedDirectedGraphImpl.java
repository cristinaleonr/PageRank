package edu.upenn.cis121.project.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import edu.upenn.cis121.project.graph.DoubleWeightedDirectedGraph;

public class DoubleWeightedDirectedGraphImpl<V> implements DoubleWeightedDirectedGraph<V> {
	List<HashMap<Integer, Integer>> adjacencyList = new ArrayList<HashMap<Integer, Integer>>();
	
	int getSize() {
        return adjacencyList.size();
    }
	
	 boolean vertexExists(int v) {
	        if (v < 0 || v >= adjacencyList.size()) {
	            return false;
	        }
	        return true;
	 }
	 
	 boolean hasEdge(int u, int v) {
	        if (!(vertexExists(u)) || !(vertexExists(v))) {
	            throw new IllegalArgumentException();
	        }
	        Set<Integer> neighbors = adjacencyList.get(u).keySet();
	        return neighbors.contains(v);
	 }
	 
	 boolean addEdge(int u, int v, int weight) {
	        if (!(vertexExists(u)) || !(vertexExists(v))) {
	            throw new IllegalArgumentException();
	        }
	        if (hasEdge(u, v)) {
	            return false;
	        } else {
	        	HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
	        	map.put(v, weight);
	            adjacencyList.get(u).putAll(map);
	            return true;
	        }
	}
	
	@Override
	public Set<V> neighbors(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<V> inNeighbors(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<V> outNeighbors(Object arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<V> vertexSet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Double> getWeight(V arg0, V arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
